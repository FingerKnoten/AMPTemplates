If the file "maps/mapname.ents" exists, it will override the original entities.
So this file have to be complete, including jumppads, teleporters etc. (Example: q3ctf4.ents)

If you want to add some items use "maps/mapname.add" instead. (Example: q3dm17.add)